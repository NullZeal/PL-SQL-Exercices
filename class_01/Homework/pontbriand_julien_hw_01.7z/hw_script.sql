CREATE OR REPLACE PROCEDURE hw1(product_price IN NUMBER) AS
	v_gst NUMBER;
	v_qst NUMBER;
	v_total NUMBER;
		BEGIN
			v_gst := product_price * 0.05;
			v_qst := product_price * 0.095;
			v_total := product_price + v_gst + v_qst;
				DBMS_OUTPUT.PUT_LINE('For a price of $' || product_price || ', you will have to pay $' || v_gst || ' GST, $' || v_qst || ' QST. Your total is $' || v_total);
					END;
						/
			